#ifndef _HEAD_H
#define _HEAD_H
struct desc_struct
{
    unsigned long a, b;
};
extern struct desc_struct idt[256], gdt[256];

#endif