# nasm ./boot/mbr.s -o ./boot/mbr.bin
# nasm ./boot/loader.s -o ./boot/loader.bin
# dd if=./boot/mbr.bin of=mbr.img bs=512 count=1 conv=notrunc
# dd if=./boot/loader.bin of=mbr.img bs=512 count=4 seek=1 conv=notrunc

gcc -c ./kernel/main.c ./lib/kernel/print.s -o main.o