nasm ./boot/mbr.s -o ./boot/mbr.bin
nasm ./boot/loader.s -o ./boot/loader.bin
ndisasm ./boot/mbr.bin > dismbr.s
ndisasm ./boot/loader.bin > disloader.s
# nasm -f elf32 -o ./lib/kernel/print.o ./lib/kernel/print.s
# gcc -m32 -c ./kernel/main.c -I /lib/kernel -o main.o
gcc  -c ./kernel/main.c -I /lib/kernel -o main.o
# ld -e _main -o kernel.bin kernel/main.o lib/kernel/print.o
ndisasm kernel.bin > diskernel.s
dd if=./boot/mbr.bin of=mbr.img bs=512 count=1 conv=notrunc
dd if=./boot/loader.bin of=mbr.img bs=512 count=12 seek=1 conv=notrunc
dd if=kernel.bin of=mbr.img bs=512 count=36 seek=13 conv=notrunc

