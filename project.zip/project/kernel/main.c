// #include "../lib/kernel/print.h"
int main(void)
{
    // put_char('k');
    // put_char('e');
    // put_char('r');
    // put_char('n');
    // put_char('e');
    // put_char('l');
    while(1)
    {
        
    }
}