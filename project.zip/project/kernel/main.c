#include "../lib/kernel/print.h"
int main(void)
{
    put_char('k');
    while(1);
}